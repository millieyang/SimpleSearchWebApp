Name: Millie Yang
E-mail: millie.yang@columbia.edu
Why Flask:
I actually learnt Flask from scratch for this web application. I know Flask is a micro framework that purposefully aims at small applications. Since this task primarily requires one POST and one GET request I thought I might use it.

How to run the application:
Navigate to the right directory on where FlaskApp is stored on Linux/Terminal.
Then type “python app.py”
Open your browser and go to “localhost:5000”
Hope you are having fun! Happy browsing!

Please refer to screenshot1, screenshot2, screenshot3, screenshot4 for a demo. Please look at the pictures in that order.

Thank you and hope you are having a nice day!

